#!/bin/bash
function startServer(){
NUMSECONDS=`expr $(date +%s)`
until ./start.sh  ; do
let DIFF=(`date +%s` - "$NUMSECONDS")
if [ "$DIFF" -gt 15 ]; then
NUMSECONDS=`expr $(date +%s)`
echo "Server './start.sh  ' crashed with exit code $?.  Respawning..." >&2 
echo "Server: [GET_TAG_NAME] Find if GETSERVERNAME or SETSERVERNAME or SERVERNAME -> Apply TAG"
fi
sleep 3
done
let DIFF=(`date +%s` - "$NUMSECONDS")
if [ ! -e "SERVER_STOPPED" ] && [ "$DIFF" -gt 15 ]; then
startServer
fi
}
startServer
