#!/bin/bash
User=""
Location=""
Game=""
IP_Domain="tdcs.sytes.net"
Ports=""
Host="Webnet Host"

echo "Server started"
sleep 1
echo "Assigned: $Location"
sleep 1
echo "Assigned: $Game"
sleep 1
echo "Assigned: $IP_Domain"
sleep 1
echo "Provider: $Host"
sleep 1
echo "Assigned: $Ports"
sleep 1
echo "Authorized: $User"
echo "Terminating this process..."
sleep 2
read -p "Press [Enter] to Terminate this session"
