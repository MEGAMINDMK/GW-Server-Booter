<?php
$answer = shell_exec("taskkill /F /IM samp-server.exe");
echo $answer."</br>"; 
//exec("C:\\xampp\\htdocs\\deathmasterpro\\filemanager\\vcmp\\serveroff.bat");
echo "<font color='white'>Game server has been shut down";
/*if($_POST['submit'] == 'Start Game Server')
{
	
}*/
/*else
{
	exec("E:\\MasterServer\\MasterServer.exe");
	echo "Master Server has been started";
}*/	

?>
<body bgcolor="black">
<link rel="icon" href="png/webnet.png" type="image/x-icon" />