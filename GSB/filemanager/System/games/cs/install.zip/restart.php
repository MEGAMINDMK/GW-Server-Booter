<?php
$answer = shell_exec("hlds.exe -console -game cstrike +hostname Top_Down_City_Server +sv_lan 0 +maxplayers 32 +map de_dust2 -port 27015");
echo $answer."</br>"; 
//exec("C:\\xampp\\htdocs\\deathmasterpro\\filemanager\\vcmp\\server.bat");
echo "<font color='white'>Game server has been restarted";
/*if($_POST['submit'] == 'Start Game Server')
{
	
}*/
/*else
{
	exec("E:\\MasterServer\\MasterServer.exe");
	echo "Master Server has been started";
}*/	

?>
<body bgcolor="black">
<link rel="icon" href="png/webnet.png" type="image/x-icon" />