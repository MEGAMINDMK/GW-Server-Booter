<?php
$answer = shell_exec("samp-server.exe");
echo $answer."</br>"; 
//exec("C:\\xampp\\htdocs\\deathmasterpro\\filemanager\\vcmp\\server.bat");
echo "<font color='white'>Game server has been started";
/*if($_POST['submit'] == 'Start Game Server')
{
	
}*/
/*else
{
	exec("E:\\MasterServer\\MasterServer.exe");
	echo "Master Server has been started";
}*/	

?>
<body bgcolor="black">
<link rel="icon" href="png/webnet.png" type="image/x-icon" />